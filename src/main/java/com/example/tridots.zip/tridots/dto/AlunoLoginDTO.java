package com.example.tridots.dto;

public record AlunoLoginDTO(
        String emailInstitucional,
        String password
) {}
