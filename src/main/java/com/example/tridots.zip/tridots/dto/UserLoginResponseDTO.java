package com.example.tridots.dto;

public record UserLoginResponseDTO(String token) {
}
