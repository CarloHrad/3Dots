package com.example.tridots.controller;

import com.example.tridots.model.Arquivo;
import com.example.tridots.repository.ArquivoRepository;
import com.example.tridots.service.ArquivoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

@RestController
@RequestMapping("/arquivo")
public class ArquivoController {
    @Autowired
    ArquivoService arquivoService;

    List<String> extensoes = List.of("stl", "obj", "fbx", "3mf", "dae", "txt");

    @PostMapping("/upload")
    public ResponseEntity<?> upload(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {return ResponseEntity.badRequest().body("Arquivo vazio!");}

        String nomeArquivo = file.getOriginalFilename();
        String extensao = nomeArquivo.substring(nomeArquivo.lastIndexOf('.')+1).toLowerCase();

        if (!extensoes.contains(extensao)) {return ResponseEntity.badRequest().body("Tipo de arquivo não permitido!");}

        Arquivo newArquivo = arquivoService.salvar(file);
        return ResponseEntity.ok(newArquivo);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Arquivo>> getAll() {
        List<Arquivo> arquivos = arquivoService.findAll();
        return ResponseEntity.ok(arquivos);
    }
}
