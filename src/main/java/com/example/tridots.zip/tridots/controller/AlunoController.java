package com.example.tridots.controller;

import com.example.tridots.dto.AlunoLoginDTO;
import com.example.tridots.dto.AlunoRegisterDTO;
import com.example.tridots.dto.AlunoResponseDTO;
import com.example.tridots.dto.UserLoginResponseDTO;
import com.example.tridots.model.Aluno;
import com.example.tridots.model.Usuario;
import com.example.tridots.repository.UsuarioRepository;
import com.example.tridots.security.TokenService;
import com.example.tridots.service.AlunoService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/aluno")
public class AlunoController {
    private static final Logger log = LoggerFactory.getLogger(AlunoController.class);

    @Autowired
    AlunoService alunoService;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    UsuarioRepository usuarioRepository;
    @Autowired
    TokenService tokenService;

    @PostMapping("/register")
    public ResponseEntity<AlunoResponseDTO> register(@RequestBody @Valid AlunoRegisterDTO alunoRegisterDTO) {

        if(this.usuarioRepository.findByEmailInstitucional(alunoRegisterDTO.emailInstitucional()) != null) {
            return ResponseEntity.badRequest().build();
        }

        AlunoResponseDTO alunoResponseDTO = alunoService.createAluno(alunoRegisterDTO);
        log.warn("Conta de Aluno requisitada");
        return ResponseEntity.status(HttpStatus.CREATED).body(alunoResponseDTO);

    }

    @PostMapping("/login")
    public ResponseEntity<UserLoginResponseDTO> login(@RequestBody @Valid AlunoLoginDTO alunoLoginDTO) {

        var usernamePassword = new UsernamePasswordAuthenticationToken(
                alunoLoginDTO.emailInstitucional(), alunoLoginDTO.password()
        );
        var auth = this.authenticationManager.authenticate(usernamePassword);
        var token = tokenService.generateToken((Usuario) auth.getPrincipal());

        return ResponseEntity.ok(new UserLoginResponseDTO(token));
    }

    @GetMapping("/get")
    public ResponseEntity<List<Usuario>> getu() throws Exception {
        List<Usuario> lista = alunoService.getUsuario(); // ou usuarioRepository.findAll()

        if (lista.isEmpty()) {
            throw new Exception("A lista está vazia"); // lança exceção
        }

        return ResponseEntity.ok(lista); // retorna a lista se não estiver vazia
    }

    @GetMapping("/usuarios")
    public ResponseEntity<List<Usuario>> getUsuarios() {
        List<Usuario> lista = alunoService.getUsuario();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204 No Content se lista vazia
        }

        return ResponseEntity.ok(lista); // 200 OK com lista
    }

    @GetMapping("/alunos")
    public ResponseEntity<List<Aluno>> getAlunos() {
        List<Aluno> lista = alunoService.getAluno();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(lista);
    }


    @GetMapping("/geta")
    public List<Aluno> geta() {
        return alunoService.getAluno();
    }
}
