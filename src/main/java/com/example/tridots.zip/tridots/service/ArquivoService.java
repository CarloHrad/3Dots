package com.example.tridots.service;

import com.example.tridots.model.Arquivo;
import com.example.tridots.repository.ArquivoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

@Service
public class ArquivoService {

    @Value("${storage.location}")
    private String localDir;

    @Autowired
    ArquivoRepository arquivoRepository;

    public Arquivo salvar(MultipartFile file) throws IOException {

        Path dir = Paths.get(localDir).toAbsolutePath();
        if (!Files.exists(dir)) {
            Files.createDirectories(dir);
        }
        String newName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
        Path dirFile = dir.resolve(newName);
        file.transferTo(dirFile.toFile());


        Arquivo arquivo = new Arquivo();
        arquivo.setNomeArquivo(file.getOriginalFilename());
        arquivo.setTipoArquivo(file.getContentType());
        arquivo.setTamanho(file.getSize());
        arquivo.setCaminho(dirFile.toString());
        System.out.println("======= Arquivo Salvo! =======");
        return arquivoRepository.save(arquivo);
    }

    public List<Arquivo> findAll() {
        return arquivoRepository.findAll();
    }

    public byte[] uploadArquivo(Long id) throws IOException {
        Arquivo arquivo = arquivoRepository.findById(id).orElseThrow(() -> new RuntimeException("Arquivo inexistente"));

        Path filePath = Paths.get(arquivo.getCaminho());
        return Files.readAllBytes(filePath);
    }

}
