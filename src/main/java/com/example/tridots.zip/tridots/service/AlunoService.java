package com.example.tridots.service;

import com.example.tridots.dto.AlunoRegisterDTO;
import com.example.tridots.dto.AlunoResponseDTO;
import com.example.tridots.enums.Cargo;
import com.example.tridots.enums.StatusMatricula;
import com.example.tridots.model.Aluno;
import com.example.tridots.model.Usuario;
import com.example.tridots.repository.AlunoRepository;
import com.example.tridots.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AlunoService {

    @Autowired
    AlunoRepository alunoRepository;
    @Autowired
    UsuarioRepository usuarioRepository;
    @Autowired
    PasswordEncoder passwordEncoder;

    public AlunoResponseDTO createAluno(AlunoRegisterDTO alunoRegisterDTO) {

        Aluno aluno = new Aluno();
        aluno.setNome(alunoRegisterDTO.nome());
        aluno.setEmailInstitucional(alunoRegisterDTO.emailInstitucional());
        aluno.setPassword(passwordEncoder.encode(alunoRegisterDTO.password()));
        aluno.setCargo(Cargo.ALUNO);
        aluno.setRaAluno(alunoRegisterDTO.raAluno());
        aluno.setCurso(alunoRegisterDTO.curso());
        aluno.setSemestre(alunoRegisterDTO.semestre());
        aluno.setStatusMatricula(StatusMatricula.ATIVA);

        System.out.println("ID ANTES E DEPOIS DO SAVE, RESPECTIVAMENTE...");
        System.out.println(aluno.getIdUsuario());
        Aluno newAluno = usuarioRepository.save(aluno);
        System.out.println("ALUNO SALVO EM ALUNO REPOSITORY");
        System.out.println(aluno.getIdUsuario());

        //retonardo criação de response do aluno
        return new AlunoResponseDTO(
                aluno.getIdUsuario(),
                aluno.getNome(),
                aluno.getEmailInstitucional(),
                aluno.getRaAluno(),
                aluno.getCurso(),
                aluno.getSemestre(),
                aluno.getStatusMatricula(),
                aluno.getCargo()
        );
    }

    public List<Usuario> getUsuario() {
        return usuarioRepository.findAll();
    }
    public List<Aluno> getAluno() {
        return alunoRepository.findAll();
    }

}
