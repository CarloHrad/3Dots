package com.example.tridots.model;

import com.example.tridots.enums.StatusPedido;
import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "statuspedido")
public class StatusPedidoClass {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idStatus;

    //MUDAR PRA PEDIDO PEDIDO
    private String pedido;
    private StatusPedido statusPedido;
    private LocalDateTime dataAlteracao;
}
