package com.example.tridots.enums;

public enum Cargo {
    ADMINISTRADOR,
    ALUNO
}
