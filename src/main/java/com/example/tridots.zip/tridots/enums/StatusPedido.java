package com.example.tridots.enums;

public enum StatusPedido {
    PENDENTE,
    ACEITO,
    RECUSADO,
    EM_PRODUCAO,
    FINALIZADO
}
