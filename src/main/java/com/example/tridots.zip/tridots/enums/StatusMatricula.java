package com.example.tridots.enums;

public enum StatusMatricula {
    ATIVA,
    INATIVA
}
