package com.example.tridots.repository;

import com.example.tridots.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.userdetails.UserDetails;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Usuario findByEmailInstitucional(String emailInstitucional);
}
