package com.example.tridots;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TridotsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TridotsApplication.class, args);
	}

}
