package com.example.tridots.dto;

public record ArquivoDTO(
        String idArquivo,
        String nome,
        String tipo
) {}
