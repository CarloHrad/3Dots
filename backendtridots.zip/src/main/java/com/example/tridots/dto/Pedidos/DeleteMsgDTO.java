package com.example.tridots.dto.Pedidos;

import com.example.tridots.model.Usuario;
import jakarta.validation.constraints.NotBlank;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;

public record DeleteMsgDTO(
        @PathVariable
        String pedidoId,
        @NotBlank(message = "O ID da mensagem é obrigatório")
        String mensagemId
) {}
