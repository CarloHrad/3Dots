package com.example.tridots;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TridotsApplicationTests {

	@Test
	void contextLoads() {
	}

}
